const express = require("express");
const { Readable } = require("stream");

const app = express();
const PORT = Number(process.env.PORT || 3000);

// IMPORTANTE: informe somente o host do seu provedor IPTV.
// Exemplo: ALLOWED_HOSTS=ded41.com
const ALLOWED_HOSTS = (process.env.ALLOWED_HOSTS || "")
  .split(",")
  .map(s => s.trim().toLowerCase())
  .filter(Boolean);

if (!ALLOWED_HOSTS.length) {
  console.warn("ALLOWED_HOSTS não configurado. O servidor não aceitará streams.");
}

app.disable("x-powered-by");
app.use(express.json({limit:"1mb"}));
app.use(express.static("public"));

function isAllowedUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { return false; }
  if (!["http:", "https:"].includes(u.protocol)) return false;
  return ALLOWED_HOSTS.some(host => u.hostname === host || u.hostname.endsWith("." + host));
}

function rejectIfNotAllowed(req, res, next) {
  const raw = req.query.url;
  if (!raw || !isAllowedUrl(raw)) {
    return res.status(403).json({
      error:"URL não autorizada",
      message:"Configure ALLOWED_HOSTS com o domínio do seu provedor IPTV."
    });
  }
  next();
}

function proxyHeaders(req) {
  const h = {};
  for (const name of ["range","if-none-match","if-modified-since"]) {
    if (req.headers[name]) h[name] = req.headers[name];
  }
  return h;
}

function copyUpstreamHeaders(up, res) {
  const allowed = [
    "content-type","content-length","content-range",
    "accept-ranges","cache-control","etag","last-modified"
  ];
  for (const k of allowed) {
    if (up.headers[k]) res.setHeader(k, up.headers[k]);
  }
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Range, Content-Type");
  res.setHeader("Access-Control-Expose-Headers",
    "Content-Length, Content-Range, Accept-Ranges, ETag");
}

async function fetchUpstream(raw, req) {
  const up = await fetch(raw, {
    method: req.method === "HEAD" ? "HEAD" : "GET",
    headers: proxyHeaders(req),
    redirect: "follow"
  });
  return up;
}

// Relay de mídia direta: TS/MP4/etc. O backend busca no provedor
// e entrega ao navegador com os headers de mídia necessários.
app.all("/api/stream", rejectIfNotAllowed, async (req,res) => {
  try {
    const up = await fetchUpstream(req.query.url, req);
    copyUpstreamHeaders(up, res);
    res.status(up.status);

    if (req.method === "HEAD" || !up.body) return res.end();
    Readable.fromWeb(up.body).pipe(res);
  } catch (e) {
    res.status(502).json({error:"Falha ao conectar ao provedor", detail:String(e.message || e)});
  }
});

// Proxy HLS: busca o .m3u8 no servidor e reescreve segmentos/chaves
// para que o navegador continue usando o backend, sem expor a URL upstream.
app.get("/api/hls", rejectIfNotAllowed, async (req,res) => {
  try {
    const raw = req.query.url;
    const up = await fetch(raw, {redirect:"follow"});
    const type = (up.headers.get("content-type") || "").toLowerCase();
    const text = await up.text();

    if (!up.ok) {
      return res.status(up.status).send(text);
    }

    // Se não for uma playlist, devolve como resposta normal.
    if (!text.includes("#EXTM3U")) {
      res.setHeader("Content-Type", type || "application/octet-stream");
      res.setHeader("Access-Control-Allow-Origin","*");
      return res.send(text);
    }

    const base = new URL(raw);
    const lines = text.split(/\r?\n/);
    const out = lines.map(line => {
      const trimmed = line.trim();

      if (!trimmed) return line;

      // URI em tags como EXT-X-KEY / EXT-X-MAP
      if (trimmed.startsWith("#") && trimmed.includes("URI=")) {
        return line.replace(/URI="([^"]+)"/g, (_, uri) => {
          try {
            const absolute = new URL(uri, base).href;
            if (!isAllowedUrl(absolute)) return `URI="${uri}"`;
            return `URI="/api/hls?url=${encodeURIComponent(absolute)}"`;
          } catch {
            return `URI="${uri}"`;
          }
        });
      }

      // Linhas de segmento ou playlist filha
      if (!trimmed.startsWith("#")) {
        try {
          const absolute = new URL(trimmed, base).href;
          if (isAllowedUrl(absolute)) {
            return `/api/hls?url=${encodeURIComponent(absolute)}`;
          }
        } catch {}
      }

      return line;
    }).join("\n");

    res.setHeader("Content-Type","application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control","no-store");
    res.setHeader("Access-Control-Allow-Origin","*");
    res.send(out);
  } catch (e) {
    res.status(502).json({error:"Falha ao buscar playlist HLS", detail:String(e.message || e)});
  }
});

app.get("/api/health", (req,res) => {
  res.json({ok:true, allowedHosts:ALLOWED_HOSTS});
});

app.listen(PORT, () => {
  console.log(`TV Supreme em http://localhost:${PORT}`);
  console.log(`Hosts autorizados: ${ALLOWED_HOSTS.join(", ") || "(nenhum)"}`);
});
