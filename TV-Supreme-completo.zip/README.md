# TV Supreme — HTML + Backend

## 1. Requisitos
- Node.js 18 ou superior
- Um servidor/VPS onde você tenha autorização para usar sua lista IPTV
- O domínio do provedor informado em ALLOWED_HOSTS

## 2. Instalar
No terminal, dentro desta pasta:

npm install

## 3. Configurar
Linux/macOS:
export ALLOWED_HOSTS=ded41.com
npm start

Windows PowerShell:
$env:ALLOWED_HOSTS="ded41.com"
npm start

Abra:
http://localhost:3000

## 4. Publicar
Em uma VPS, use HTTPS (por exemplo, Nginx/Caddy na frente do Node).
Configure ALLOWED_HOSTS para o domínio exato do provedor.

## Segurança
Este projeto NÃO é um proxy aberto. O endpoint /api/stream só aceita URLs
cujo hostname esteja em ALLOWED_HOSTS. Não remova essa validação.

O M3U é lido no navegador; as credenciais contidas nas URLs não são gravadas
pelo backend. Evite publicar o arquivo M3U ou compartilhar suas credenciais.

## Limitação importante
O relay não transforma qualquer formato em MP4. Se o provedor entregar MPEG-TS
ao vivo e o navegador não conseguir reproduzir, será necessário adicionar FFmpeg
no servidor para remux/transcodificar para HLS. Isso depende do formato entregue
pelo provedor e dos recursos da VPS.

## Uso autorizado
Use o servidor somente com streams para os quais você tenha autorização.
